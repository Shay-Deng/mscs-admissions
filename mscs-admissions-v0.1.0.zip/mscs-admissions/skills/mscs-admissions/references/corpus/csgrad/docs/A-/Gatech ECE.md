# Gatech ECE

# 项目介绍

学位：Master of Science in Electrical & Computer Engineering，简称 MSECE。

校区：主打亚特兰大本部，也可以去法国洛林/深圳兜一圈。

毕业门槛：30学分➕必修一门超水课 ECE 6001（演讲+创业扯闲篇）。

节奏：最快 3 个学期搞定，但是没上岸的话也可以拖着让你拖到 5 年都行，上岸再毕业；可以GRIP回国实习同时维持在学校注册，不影响cpt申请；转phd友好。学期中可以在美国COOP实习，听说也可以去别的国家实习GRIP。并且算学分，还是不错的。

选课：6 门 ECE 核心随你挑（可以全选偏软的）；外加 4 门随便跨学院，CS / CSE / ISyE 统统都能上。VLSI有一门很热门的Tape-out课（需要连续上两个学期），第一个学期做deisgn，寒/暑假前会送去Tape-out，寒/暑假结束，chip回来后再做test。
Fall semester开Digital的（和Apple合作），Spring semester开Analog的（和TI合作）。如果你想去做VLSI，可以关注一下

想当ta的话省学费的话，一定要尽早联系教授。我第一学期就修了6001，但上学期11月底的时候联系教授问能不能当下学期的助教，教授说早就面试完了。



## 录取bar 和dp
东亚人1/4，印度人1/4，美国人1/4，其余1/4。
美本友好型，喜欢ece本科出身的

1. iit cs本科gpa 3.9. mathworks 两年全职
2. gatech ece本科gpa4.0
3. gatech ece本科，有google step实习

## 找工dp
硬件岗位和软件岗位都有，整体找工情况较好

1. gatech ece本科，无实习上岸硬件厂
2. gatech ece本科有小厂硬件实习，上岸apple
3. gatech ece本科，上岸nvidia 实习并且转正
4. 印度本科，nvidia 硬件两年全职，上岸美国amd 全职
5. gatech ece本科，有intel 实习，上岸arm实习
6. 印度本科，blackrock一年半全职，上岸apple硬件岗位
7. usc本科，有小厂sde intern，上岸amd硬件intern
8. 陆本，北美大厂intern，上岸amazon
9. 陆本，中厂intern，上岸apple硬件岗
10. 陆本，上岸nvidia,amazon intern
11. NIT Tiruchirappalli ee本科，入学前 google Embedded swe 两年全职，2025年 Astera Labs Firmware intern，2026年 nvidia Firmware Engineer 全职。

# 选课


Round 1：只给本专业选。

Round 2：临开学再解锁全校课，热门 CS 课要盯着 Wait‑list 刷空位。Round2 最后一天下午开启大乱斗，waitlist清空，可以拼手速捡漏

超学分不加钱——12 学分之外免费，你要是体力够，4+1 甚至 4+2 都没人拦你。

![](/img/gtececourse.png)

# 来了gt，怎么进行找实习准备

![](/img/gtecetimeline.png)
