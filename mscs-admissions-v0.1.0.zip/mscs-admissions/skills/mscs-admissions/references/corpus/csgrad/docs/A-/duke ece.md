---
sidebar_position: 2
---
# Duke ECE

## 项目介绍
Duke 一共有三个cs相关的项目，1. Mscs 2. Ece 3. Game design。其中mscs是一个偏向科研型的项目，ece是偏向转码+找工作的项目。

总体上来看，ece课程更SDE导向，且bar更友好（翻译：更容易申请，并且也有很多转码的同学来申请，申请时候大概率会有面试，是考口语的。

ECE总共有两个大类，一个是MS，一个是MENG👋。区别就是前者需要写thesis，后者不需要，并且meng需要上两门商学院的课，并且要有实习才能毕业。往年来看第一个ms的hc是100个，meng是5-10个🤣。官方回复是说meng和ms的bar是一样的，如果录了ms，meng也可以录，如果录了meng，ms也可以录。这俩入学后可以互相转✅

## Pros：
1. 项目的课程质量比较好。有秋季三件套（550，551，590）和春季三件套（650，651，568），基本都是SDE相关的课。如果是转码且基础相对比较薄弱的同学可以补一下基础。春季三件套的wld相对比较大，比如ECE 651 SOFTWARE ENGINEERING，会花很多时间，但是同样能帮忙打好基础。
2. coop。meng可以coop 一次，有coop就是有一张复活卡，秋季招coop的公司有Tesla、snowflake、tiktok等🍾。从邮件上来看，24fall之后的meng ece都是可以coop的，秋季能有coop的学校相对较少，因此竞争少一点，上岸概率更大。
3. 可以转码。申请Duke ece时候会让你填写是想申请meng还是ms, 转码/cs科班同学可以选Software Development👊和Data Analytics & Machine Learning track。文书也比较好写一点（前者写sde文书，后者写做科研的文书）。当然track进入学校后都可以互相转的
4. 人相对比较少，过简历关相对容易。有些公司在最后发offer时候会参考一下已经招了这个学校的ng的人数，必然不可能说全都招一个学校的。因此人数少的学校在过简历时候会有优势。



## Cons：
1. 贵，单学费就将近十万刀（来源：学校官网）了。当时我申请时候看到这个学费真的吓了一大跳，不愧是私立。
2. Wld比较大。如前文所言，春季+秋季三件套都是wld比较大的，因此可能会影响刷题时间


## 录取dp
接受转码，整体上来看难度不大，gpa3.7+ 托福过线即可

1. 西交利物浦ee本科gpa3.88
2. 大连理工管理系，gpa top 15%, 有伯克利交换
3. 电子科大通信本科，gpa3.75,
4. 深圳大学cs本科gpa3.75,有美团、腾讯、shopee、携程实习
5. 东华大学软工本科gpa3.9
6. 电子科技大学软工本科gpa3.9

## 找工dp
1. osu cs本科，有校内实习和国内小厂实习，上岸纽约小厂ng
2. 电子科大通信本科，有携程实习和测试小厂实习，上岸uber ng
3. 南开cs本科，有两段小厂实习和字节ba实习，上岸datavisor intern
4. 德国cs本科 gpa4.0，有一段国内小厂实习，上岸硬件厂ng
5. 东华大学软工本科无实习，上岸hp实习，后ng上岸amazon
6. 电子科技大学软工本科有国内小厂实习，后ng上岸amazon
7. duke kunshan ds本科，有上海飞利浦实习，上岸小厂intern
8. 东南大学自动化本科，读 Duke ECE MS，2022年 microsoft swe intern，2023年 nvidia swe intern，2024年 nvidia swe 全职。
