## 录取偏好

## 代表性 dp

## 网申备注

## 项目特点

学费极其便宜，大概一年学费只要 3 万出头（大概 18 个学分的钱），如果 ta 或者 ra 的话更加便宜

## 申请季实时信息

## 介绍帖

[回到列表 :fontawesome-solid-house:](grade.md){ .md-button }
