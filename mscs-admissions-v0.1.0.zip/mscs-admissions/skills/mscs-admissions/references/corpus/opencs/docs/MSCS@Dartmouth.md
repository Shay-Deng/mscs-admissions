## 录取偏好

藤校，非常看 SoP 和代码 sample。

## 代表性 dp

## 网申备注

申请费用只要 40 刀，非常非常的实惠

## 项目特点

可能给大额奖（50%-75%），甚至全额，但学费很贵，近$2w per term, 整个项目 7 个 terms. 非全奖学费仍然不低

## 申请季实时信息

## 介绍帖

[回到列表 :fontawesome-solid-house:](grade.md){ .md-button }
