## 录取偏好

陆本每年抽奖者众多，录取极少

## 代表性 dp

【22fall】一个 18 级 HKUST 的大佬 (计算机 + 数学)，GPA 大概 4/4.3，有交换经历，做云计算的，科研有一篇二作一篇三作（20 年以来 citations：140+），实习有阿里云、腾讯优图、goldman sachs，ACM 区域赛金牌和银牌，录取

## 网申备注

## 项目特点

## 申请季实时信息

## 介绍帖

[回到列表 :fontawesome-solid-house:](grade.md){ .md-button }
