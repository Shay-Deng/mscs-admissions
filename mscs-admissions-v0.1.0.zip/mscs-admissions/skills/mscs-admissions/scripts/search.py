"""Offline document retrieval; no admission score or guessed probability."""
import argparse,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser();p.add_argument('query');p.add_argument('--limit',type=int,default=8);a=p.parse_args()
    terms=a.query.casefold().split();data=json.loads((ROOT/'references/sources.json').read_text());found=[]
    for d in data['documents']:
        path=ROOT/d['file'];body=path.read_text();low=body.casefold()
        if all(t in low or t in d['file'].casefold() for t in terms):
            score=sum(5*(t in d['file'].casefold())+low.count(t) for t in terms);found.append((score,d,body))
    for _,d,body in sorted(found,key=lambda r:r[0],reverse=True)[:a.limit]:
        lines=body.splitlines();matches=[{'line':i+1,'text':line[:800]} for i,line in enumerate(lines) if any(t in line.casefold() for t in terms)]
        print(json.dumps({**d,'matches':matches[:12]},ensure_ascii=False))
if __name__=='__main__':main()
