import copy,sys,pathlib,unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'skills/mscs-admissions/scripts'))
from prepare_dp import prepare
from query_dp import select_portfolios

def row(rid,app,school,result='Admit',year=2026,scale='4.0'):
    return {'d':{'id':rid,'applicant_id':app,'result':result,'academic_year':year,'semester':'Fall'},'a':{'gpa':3.9,'gpa_scale':scale,'contact_info':'private@example.test'},'p':{'school':school,'program':'MSCS'}}
class DataTests(unittest.TestCase):
    def test_full_portfolio(self):
        r,_,_=prepare([row('1','a','USC'),row('2','a','Stanford'),row('3','b','USC','Reject')]);p=select_portfolios(r,school='USC')
        self.assertEqual(len(p),2);self.assertEqual(sorted(len(x['outcomes']) for x in p),[1,2]);self.assertEqual(sum(r['result']=='Reject' for x in p for r in x['outcomes']),1)
    def test_seasons(self):
        r,g,_=prepare([row('1','a','USC',year=2025),row('2','a','Stanford')]);self.assertEqual(len(g),2);self.assertEqual(len(select_portfolios(r,school='USC')[0]['outcomes']),1)
    def test_scales(self):
        r,_,_=prepare([row('1','a','USC'),row('2','b','USC',scale='4.3')]);self.assertEqual(len(select_portfolios(r,scale='4.0',gpa_min=3.8)),1)
        with self.assertRaises(ValueError):select_portfolios(r,gpa_min=3.8)
    def test_missing_identity(self):
        _,g,_=prepare([row('1',None,'USC'),row('2',None,'Stanford')]);self.assertEqual(len(g),2)
    def test_exclusion_and_allowlist(self):
        a=row('1','a','USC');b=row('2','b','USC');b['d']['notes']='AUTOMATED SUBMISSION TEST — DELETE'
        r,_,e=prepare([a,a,b]);self.assertEqual(len(r),1);self.assertEqual(len(e),2);self.assertNotIn('contact_info',r[0]['profile'])
    def test_non_decisions_preserved(self):
        r,_,_=prepare([row(str(i),'a','USC',result=v) for i,v in enumerate(['Withdraw','Waitlist',None,'默拒'])]);self.assertEqual([x['result'] for x in r],['Withdraw','Waitlist',None,'默拒'])
if __name__=='__main__':unittest.main()
